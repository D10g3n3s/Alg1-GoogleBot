#ifndef MENU_H
    #define MENU_H

    #include "list.h"

    void menu(LINKED_LIST *list);

#endif