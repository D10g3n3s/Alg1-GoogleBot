#ifndef UTILS_H
    #define UTILS_H

    #include <stdio.h>

    char *readLine(FILE *input);
    char *readWord(FILE *input);
    char *myStrndump(const char *string, int size);

#endif