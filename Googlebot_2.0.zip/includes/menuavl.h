#ifndef MENUAVL_H
    #define MENUAVL_H

    #include <avl.h>

    void menuAVL(AVL *tree);

#endif